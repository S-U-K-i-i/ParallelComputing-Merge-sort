#include <iostream>
#include <omp.h>
#include <cstdlib>
#include <ctime>
#include <algorithm>

void merge(int arr[], int left[], int left_size, int right[], int right_size) {
    int i = 0, j = 0, k = 0;
    int* tmp = new int[left_size + right_size];

    while (i < left_size && j < right_size) {
        if (left[i] <= right[j]) {
            tmp[k++] = left[i++];
        } else {
            tmp[k++] = right[j++];
        }
    }
    while (i < left_size) {
        tmp[k++] = left[i++];
    }
    while (j < right_size) {
        tmp[k++] = right[j++];
    }

    memcpy(arr, tmp, (left_size + right_size) * sizeof(int));
    delete[] tmp;
}

void merge_sort(int arr[], int size) {
    if (size < 2) {
        return;
    }

    int mid = size / 2;
    int* left = arr;
    int left_size = mid;
    int* right = arr + mid;
    int right_size = size - mid;

    merge_sort(left, left_size);
    merge_sort(right, right_size);

    merge(arr, left, left_size, right, right_size);
}

int main() {
    int SIZE;
    int choice;

    std::cout << "User input or random: \n 1. User Input\n 2. Random Array\n";
    std::cin >> choice;

    std::cout << "Enter the size of the array: ";
    std::cin >> SIZE;

    int* arr = new int[SIZE];

    if(choice == 1){

        printf("Unsorted array: ");

        for(int i = 0 ; i < SIZE ; i++)
            std::cin >> arr[i];

    }else if(choice == 2){
        // Generate array of random integers
        srand(time(NULL));
        for (int i = 0; i < SIZE; i++) {
            arr[i] = rand() % 100;
        }

        printf("Unsorted array: ");

        for (int i = 0; i < SIZE; i++) {
            std::cout << arr[i] << " ";
        }
    }else{
        std::cout << "Invalid";
    }

    printf("\n");

    double start_time = omp_get_wtime();

    // Sequential merge sort
    merge_sort(arr, SIZE);

    double end_time = omp_get_wtime();

    printf("Sorted array: ");
    for (int i = 0; i < SIZE; i++) {
        std::cout << arr[i] << " ";
    }
    std::cout << std::endl;

    printf("Total execution time: %f seconds\n", end_time - start_time);

    delete[] arr;
    return 0;
}


#include <iostream>
#include <omp.h>
#include <cstdlib>
#include <ctime>

using namespace std;

void merge(int arr[], int l, int m, int r, int temp[]) {
    int i = l, j = m + 1, k = l;
    while (i <= m && j <= r) {
        if (arr[i] <= arr[j])
            temp[k++] = arr[i++];
        else
            temp[k++] = arr[j++];
    }
    while (i <= m)
        temp[k++] = arr[i++];
    while (j <= r)
        temp[k++] = arr[j++];
    for (i = l; i <= r; i++)
        arr[i] = temp[i];
}

void merge_sort(int arr[], int l, int r, int temp[], int chunk_size) {
    if (l < r) {
        int m = l + (r - l) / 2;
        #pragma omp task shared(arr,temp) if(r-l > chunk_size)
        merge_sort(arr, l, m, temp, chunk_size);
        #pragma omp task shared(arr,temp) if(r-l > chunk_size)
        merge_sort(arr, m + 1, r, temp, chunk_size);
        #pragma omp taskwait
        merge(arr, l, m, r, temp);
    }
}

int main() {
    int n;
    int choice;

    std::cout << "User input or random: \n 1. User Input\n 2. Random Array\n";
    std::cin >> choice;

    cout << "Enter the size of the array: ";
    cin >> n;

    int* arr = new int[n];
    int* temp = new int[n];

    if(choice == 1){

        printf("Unsorted array: ");

        for(int i = 0 ; i < n ; i++)
            std::cin >> arr[i];

    }else if(choice == 2){
        srand(time(NULL));
        for (int i = 0; i < n; i++)
            arr[i] = rand() % 1000;

        printf("Unsorted array: ");

        for (int i = 0; i < n; i++) {
            std::cout << arr[i] << " ";
        }
    }else{
        std::cout << "Invalid";
    }

    double start_time = omp_get_wtime();
    #pragma omp parallel shared(arr,temp)
    {
        #pragma omp single nowait
        merge_sort(arr, 0, n - 1, temp, 100);
    }
    double end_time = omp_get_wtime();

    cout << endl;

    cout << "Sorted array: ";
    for (int i = 0; i < n; i++)
        cout << arr[i] << " ";
    cout << endl;
    cout << "Execution time: " << end_time - start_time << " seconds" << endl;
    delete[] arr;
    delete[] temp;
    return 0;
}
